import { NextRequest, NextResponse } from 'next/server'
import fs from 'fs'

// Intent types
type Intent = 'COUNT_INTERACTION' | 'COUNT_KELUHAN' | 'CHECK_TOPIC' | 'SUMMARY' | 'UNKNOWN'

interface DetectedIntent {
  intent: Intent
  customer: string | null
  topic: string | null
  confidence: number
}

// Intent detection patterns
const PATTERNS = {
  COUNT_INTERACTION: [
    /berapa\s+kali\s+(?:pernah\s+)?(?:bertanya|melaporkan|interaksi|tiket)/i,
    /jumlah\s+(?:pertanyaan|laporan|interaksi|tiket)/i,
    /total\s+(?:pertanyaan|laporan|interaksi|tiket)/i,
    /berapa\s+(?:pertanyaan|laporan|interaksi|tiket)/i
  ],
  COUNT_KELUHAN: [
    /total\s+keluhan/i,
    /jumlah\s+keluhan/i,
    /berapa\s+keluhan/i
  ],
  CHECK_TOPIC: [
    /apakah\s+(?:pernah\s+)?(?:bertanya|melaporkan)\s+(?:tentang|dalam)\s+(.+)/i,
    /ada\s+(?:pertanyaan|laporan)\s+(?:tentang|dalam)\s+(.+)/i,
    /pernah\s+(?:ada\s+)?(?:tanya|lapor)\s+(?:tentang|dalam)\s+(.+)/i
  ],
  SUMMARY: [
    /ringkasan\s+(?:masalah|laporan|tiket)\s+customer/i,
    /summary\s+(?:problem|issue|ticket)\s+customer/i,
    /laporan\s+customer/i
  ]
}

// Extract customer name from question
function extractCustomerName(question: string): string | null {
  const customerMatch = question.match(/customer\s+([a-zA-Z0-9\s\-_.]+)/i)
  if (customerMatch) {
    return customerMatch[1].trim().split(/\s+/)[0]
  }
  return null
}

// Extract topic from question
function extractTopic(question: string): string | null {
  const topicMatch = question.match(/(?:tentang|dalam)\s+(.+?)(?:\?|$)/i)
  if (topicMatch) {
    return topicMatch[1].trim()
  }
  return null
}

// Detect intent from question
function detectIntent(question: string): DetectedIntent {
  const customer = extractCustomerName(question)
  let intent: Intent = 'UNKNOWN'
  let topic: string | null = null
  let confidence = 0

  for (const [intentType, patterns] of Object.entries(PATTERNS)) {
    for (const pattern of patterns) {
      const match = question.match(pattern)
      if (match) {
        intent = intentType as Intent
        confidence = 0.8

        if (intentType === 'CHECK_TOPIC' && match[1]) {
          topic = match[1].trim()
        }

        break
      }
    }
    if (confidence > 0) break
  }

  if (intent === 'UNKNOWN' && customer) {
    intent = 'SUMMARY'
    confidence = 0.5
  }

  return { intent, customer, topic, confidence }
}

// Fetch data from JSON database (customer_log.json)
async function getDatabaseData() {
  try {
    const dbPath = '/home/z/my-project/db/customer_log.json'
    console.log('Reading database from:', dbPath)

    const jsonContent = fs.readFileSync(dbPath, 'utf8')
    console.log('Database file size:', jsonContent.length)

    const data = JSON.parse(jsonContent)
    console.log('Total records in database:', data.length)

    return data
  } catch (error) {
    console.error('Error fetching database data:', error)
    throw error
  }
}

// Check if any text matches
function matchesAny(text: string, terms: string[]): boolean {
  const lowerText = text.toLowerCase()
  return terms.some(term => {
    const lowerTerm = term.toLowerCase()
    return lowerText.includes(lowerTerm) || lowerTerm.includes(lowerText)
  })
}

// Process data based on intent
async function processData(intent: DetectedIntent, data: any[]) {
  const { intent: type, customer, topic } = intent

  console.log('Processing data for customer:', customer)
  console.log('Topic to search:', topic)
  console.log('Total rows in database:', data.length)

  // Filter rows by customer (customer_name or customer_code)
  const customerRows = customer
    ? data.filter(row => {
        const customerName = row.customer_name?.toLowerCase() || ''
        const customerCode = row.customer_code?.toLowerCase() || ''
        return customerName === customer.toLowerCase() ||
               customerCode === customer.toLowerCase()
      })
    : data

  console.log('Customer rows matched:', customerRows.length)
  if (customerRows.length > 0) {
    console.log('First customer row:', customerRows[0])
  }

  switch (type) {
    case 'COUNT_INTERACTION': {
      const count = customerRows.length
      return {
        intent: 'COUNT_INTERACTION',
        customer,
        total_interaction: count
      }
    }

    case 'COUNT_KELUHAN': {
      const keluhanCount = customerRows.filter(row => {
        const keluhanValue = row.keluhan || ''
        return keluhanValue && keluhanValue.toString().trim() !== '' &&
               keluhanValue.toString().toLowerCase() !== '-'
      }).length

      return {
        intent: 'COUNT_KELUHAN',
        customer,
        total_keluhan: keluhanCount
      }
    }

    case 'CHECK_TOPIC': {
      if (!topic) {
        return {
          intent: 'CHECK_TOPIC',
          customer,
          topic: null,
          count: 0,
          error: 'Topik tidak ditemukan dalam pertanyaan'
        }
      }

      // Split topic into words for better matching
      const topicWords = topic.split(/\s+/).filter(w => w.length > 2)
      console.log('Topic words for matching:', topicWords)

      // Search in multiple fields with word-level matching
      const matchingRows = customerRows.filter(row => {
        const keluhanText = (row.keluhan || '').toLowerCase()
        const menuText = (row.menu || '').toLowerCase()
        const platformText = (row.platform || '').toLowerCase()

        // Check if any topic word matches
        return topicWords.some(word => {
          const lowerWord = word.toLowerCase()
          return keluhanText.includes(lowerWord) ||
                 menuText.includes(lowerWord) ||
                 platformText.includes(lowerWord)
        })
      })

      console.log('Matching rows:', matchingRows.length)
      
      if (matchingRows.length > 0) {
        console.log('Matched examples:')
        matchingRows.slice(0, 3).forEach((r, i) => {
          console.log(`  ${i+1}. [${r.customer_code}] ${r.menu}`)
        })
      }

      return {
        intent: 'CHECK_TOPIC',
        customer,
        topic,
        count: matchingRows.length
      }
    }

    case 'SUMMARY': {
      const totalInteraction = customerRows.length

      const keluhanCount = customerRows.filter(row => {
        const keluhanValue = row.keluhan || ''
        return keluhanValue && keluhanValue.toString().trim() !== '' &&
               keluhanValue.toString().toLowerCase() !== '-'
      }).length

      const keluhanTexts = customerRows
        .filter(row => {
          const keluhanValue = row.keluhan || ''
          return keluhanValue && keluhanValue.toString().trim() !== '' &&
                 keluhanValue.toString().toLowerCase() !== '-'
        })
        .map(row => row.keluhan?.toString().trim() || '')

      const uniqueTopics = [...new Set(keluhanTexts)].length
      
      // Get platforms
      const platforms = new Set(customerRows.map(row => row.platform).filter(p => p))

      // Get open vs closed tickets
      const openTickets = customerRows.filter(row => row.status === 'Open').length
      const closedTickets = customerRows.filter(row => row.status === 'Closed').length

      return {
        intent: 'SUMMARY',
        customer,
        total_interaction: totalInteraction,
        total_keluhan: keluhanCount,
        total_pertanyaan: keluhanCount,
        unique_topics: uniqueTopics,
        platforms: Array.from(platforms),
        open_tickets: openTickets,
        closed_tickets: closedTickets
      }
    }

    default:
      return {
        intent: 'UNKNOWN',
        customer,
        error: 'Intent tidak dikenali'
      }
  }
}

// Generate natural language response
function generateResponse(data: any): string {
  switch (data.intent) {
    case 'COUNT_INTERACTION':
      if (!data.customer) return 'Maaf, nama customer tidak ditemukan dalam pertanyaan.'
      if (data.total_interaction === 0) return `Data tidak ditemukan untuk customer ${data.customer}.`
      return `Customer ${data.customer} tercatat pernah bertanya sebanyak ${data.total_interaction} kali.`

    case 'COUNT_KELUHAN':
      if (!data.customer) return 'Maaf, nama customer tidak ditemukan dalam pertanyaan.'
      if (data.total_keluhan === 0) return `Customer ${data.customer} tidak memiliki data keluhan.`
      return `Customer ${data.customer} memiliki ${data.total_keluhan} keluhan tercatat.`

    case 'CHECK_TOPIC':
      if (!data.customer) return 'Maaf, nama customer tidak ditemukan dalam pertanyaan.'
      if (!data.topic) return 'Maaf, topik tidak ditemukan dalam pertanyaan.'
      if (data.count === 0) return `Customer ${data.customer} tidak memiliki pertanyaan atau laporan tentang "${data.topic}".`
      return `Ya, customer ${data.customer} pernah bertanya atau melaporkan tentang "${data.topic}" sebanyak ${data.count} kali.`

    case 'SUMMARY':
      if (!data.customer) return 'Maaf, nama customer tidak ditemukan dalam pertanyaan.'
      if (data.total_interaction === 0) return `Data tidak ditemukan untuk customer ${data.customer}.`
      return `Ringkasan untuk customer ${data.customer}:\n` +
             `- Total interaksi: ${data.total_interaction}\n` +
             `- Total keluhan: ${data.total_keluhan}\n` +
             `- Total pertanyaan: ${data.total_pertanyaan}\n` +
             `- Topik unik: ${data.unique_topics}\n` +
             `- Platforms: ${data.platforms.join(', ')}\n` +
             `- Tiket Open: ${data.open_tickets}\n` +
             `- Tiket Closed: ${data.closed_tickets}`

    default:
      return 'Maaf, saya tidak mengerti pertanyaan Anda. Silakan gunakan format pertanyaan yang sesuai.'
  }
}

export async function GET() {
  return NextResponse.json({ message: "Customer Data Analyst API - Customer Log Database Version" });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { question } = body

    if (!question || typeof question !== 'string') {
      return NextResponse.json(
        { error: 'Question is required' },
        { status: 400 }
      )
    }

    console.log('Processing question:', question)

    const detectedIntent = detectIntent(question)
    console.log('Detected intent:', detectedIntent)

    if (detectedIntent.intent === 'UNKNOWN') {
      return NextResponse.json({
        answer: 'Maaf, saya tidak mengerti pertanyaan Anda. Silakan gunakan format pertanyaan yang sesuai.',
        intent: detectedIntent
      })
    }

    const data = await getDatabaseData()

    const processedData = await processData(detectedIntent, data)

    const answer = generateResponse(processedData)

    return NextResponse.json({
      answer,
      data: processedData,
      intent: detectedIntent
    })

  } catch (error) {
    console.error('Error processing query:', error)
    return NextResponse.json(
      {
        answer: 'Maaf, terjadi kesalahan saat memproses pertanyaan Anda.',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
